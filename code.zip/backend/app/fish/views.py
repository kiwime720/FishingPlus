# app/fish/views.py
from flask import Blueprint, jsonify

fish_bp = Blueprint('fish', __name__, url_prefix='/api/fish')

@fish_bp.route('/list')
def list_fish():
    return jsonify(fish=['mackerel', 'tuna', 'salmon'])

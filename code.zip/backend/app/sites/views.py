# app/sites/views.py
from flask import Blueprint, jsonify

sites_bp = Blueprint('sites', __name__, url_prefix='/api/sites')

@sites_bp.route('/list')
def list_sites():
    return jsonify(sites=['Harbor A', 'Bay B', 'Port C'])
